# LUMEN — Explainable Connect Four AI

A Connect Four game played against an MCTS (Monte Carlo Tree Search) agent that
explains every move it makes — in plain language, backed by real search statistics —
set against a live 3D particle background.

## What's inside

- **Full Connect Four rules** — 7×6 board, horizontal/vertical/diagonal win detection, draws.
- **MCTS agent** (`js/mcts.js`) — runs thousands of simulated playouts per move (selection →
  expansion → simulation → backpropagation, UCT formula), layered under two tactical
  overrides: take an immediate win, block an immediate loss.
- **Move justification** — after every AI move, the side panel shows *why*: the tactical
  reason if there was one, or the search stats (visits %, win rate) per candidate column,
  plus notes on board centrality and disc connectivity.
- **3D particle frontend** — Three.js ambient particle field with mouse parallax, plus
  reactive light bursts on every drop and a celebration burst on game end.

## Run it in VS Code

No build step, no npm install required — it's a static site.

**Easiest:** open the folder in VS Code, install the **Live Server** extension
(by Ritwick Dey) if you don't have it, right-click `index.html` → **Open with Live Server**.

**Or, without any extension:** just double-click `index.html` to open it in your browser.

**Or, with Node installed:**
```bash
npx serve .
```
then open the printed local URL.

> The 3D particles and fonts load from a CDN, so you'll need an internet connection the
> first time; the game itself works fully offline once loaded. If Three.js fails to load,
> the particle canvas is skipped automatically and the game still plays normally.

## Files

```
index.html          page shell
css/style.css        design system + layout
js/connect4.js        board state, rules, win detection
js/mcts.js             MCTS agent + explanation generator
js/particles.js        Three.js particle field and burst effects
js/ui.js                DOM rendering / board interaction
js/main.js               game loop, wires everything together
```

## Tuning the agent

The "Agent depth" dropdown in the top bar controls the search time budget per move
(Quick ≈0.8s, Balanced ≈2.2s, Deep ≈5s of simulated playouts). Deeper search means more
simulations, tighter win-rate estimates, and generally stronger, more confident play.


## GitHub

This repository is a static website. To publish it with GitHub Pages:

1. Upload these project files to a GitHub repository.
2. Open **Settings → Pages** in the repository.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Choose the `main` branch and `/ (root)`, then save.
5. Wait for deployment and open the Pages URL shown in Settings.

No API keys, secrets, or dependency installation are required.
