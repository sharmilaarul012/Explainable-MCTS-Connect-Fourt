/**
 * Connect4 core rules engine.
 * Board representation: 2D array [ROWS][COLS], row 0 = top, row ROWS-1 = bottom.
 * Cell values: null (empty), 'red', 'yellow'.
 */
const C4 = (() => {
  const ROWS = 6;
  const COLS = 7;

  function createBoard() {
    return Array.from({ length: ROWS }, () => Array(COLS).fill(null));
  }

  function cloneBoard(board) {
    return board.map(row => row.slice());
  }

  function opponent(player) {
    return player === 'red' ? 'yellow' : 'red';
  }

  function getValidColumns(board) {
    const cols = [];
    for (let c = 0; c < COLS; c++) {
      if (board[0][c] === null) cols.push(c);
    }
    return cols;
  }

  function isColumnValid(board, col) {
    return col >= 0 && col < COLS && board[0][col] === null;
  }

  // Returns { board, row } with the piece placed, or null if column full/invalid.
  function dropPiece(board, col, player) {
    if (!isColumnValid(board, col)) return null;
    const newBoard = cloneBoard(board);
    for (let r = ROWS - 1; r >= 0; r--) {
      if (newBoard[r][col] === null) {
        newBoard[r][col] = player;
        return { board: newBoard, row: r, col };
      }
    }
    return null;
  }

  // In-place drop, mutates board. Returns the row the piece landed on, or -1.
  function dropPieceMutate(board, col, player) {
    for (let r = ROWS - 1; r >= 0; r--) {
      if (board[r][col] === null) {
        board[r][col] = player;
        return r;
      }
    }
    return -1;
  }

  function undropMutate(board, col) {
    for (let r = 0; r < ROWS; r++) {
      if (board[r][col] !== null) {
        board[r][col] = null;
        return r;
      }
    }
    return -1;
  }

  const DIRECTIONS = [
    { dr: 0, dc: 1 },  // horizontal
    { dr: 1, dc: 0 },  // vertical
    { dr: 1, dc: 1 },  // diagonal down-right
    { dr: 1, dc: -1 }, // diagonal down-left
  ];

  // Returns the winning cell coordinates [{r,c}, x4] or null.
  function checkWin(board, player) {
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        if (board[r][c] !== player) continue;
        for (const { dr, dc } of DIRECTIONS) {
          const cells = [];
          for (let i = 0; i < 4; i++) {
            const rr = r + dr * i;
            const cc = c + dc * i;
            if (rr < 0 || rr >= ROWS || cc < 0 || cc >= COLS) { cells.length = 0; break; }
            if (board[rr][cc] !== player) { cells.length = 0; break; }
            cells.push({ r: rr, c: cc });
          }
          if (cells.length === 4) return cells;
        }
      }
    }
    return null;
  }

  function isDraw(board) {
    return getValidColumns(board).length === 0;
  }

  function isTerminal(board) {
    return !!checkWin(board, 'red') || !!checkWin(board, 'yellow') || isDraw(board);
  }

  // Would placing `player` in `col` immediately win? Returns winning cells or null.
  function moveWinsImmediately(board, col, player) {
    const result = dropPiece(board, col, player);
    if (!result) return null;
    return checkWin(result.board, player);
  }

  // Counts, for a hypothetical piece at (r,c) belonging to player, how many
  // same-color neighbours it touches (used for "connectivity" explanations).
  function countNeighbourConnections(board, r, c, player) {
    let count = 0;
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const rr = r + dr, cc = c + dc;
        if (rr < 0 || rr >= ROWS || cc < 0 || cc >= COLS) continue;
        if (board[rr][cc] === player) count++;
      }
    }
    return count;
  }

  // How many distinct "open" 4-in-a-row windows pass through this column,
  // used to describe positional/centrality value.
  const COLUMN_WINDOW_COUNTS = [3, 4, 5, 7, 5, 4, 3];

  return {
    ROWS, COLS,
    createBoard, cloneBoard, opponent,
    getValidColumns, isColumnValid,
    dropPiece, dropPieceMutate, undropMutate,
    checkWin, isDraw, isTerminal,
    moveWinsImmediately, countNeighbourConnections,
    COLUMN_WINDOW_COUNTS,
  };
})();
