/**
 * Explainable MCTS agent for Connect Four.
 *
 * Decision pipeline, in order:
 *  1. Immediate win check       -> if a move wins right now, take it (tactical).
 *  2. Immediate block check     -> if the opponent would win next turn, block it (tactical).
 *  3. Monte Carlo Tree Search   -> otherwise, search and pick the most-visited root move.
 *
 * Every decision returns a structured explanation object, not just a column index,
 * so the UI can render *why* the move was chosen.
 */
const MCTSAgent = (() => {

  class Node {
    constructor(board, toMove, parent = null, moveFromParent = null) {
      this.board = board;
      this.toMove = toMove;                 // player who moves next from this state
      this.justMoved = parent ? MCTSAgent._other(toMove) : null;
      this.parent = parent;
      this.moveFromParent = moveFromParent; // column that produced this node
      this.children = [];
      this.untried = C4.getValidColumns(board);
      this.visits = 0;
      this.wins = 0; // wins credited to `justMoved`, from this subtree
    }
  }

  function _other(p) { return p === 'red' ? 'yellow' : 'red'; }

  function uctSelectChild(node, explorationC) {
    let best = null, bestScore = -Infinity;
    for (const child of node.children) {
      const exploit = child.wins / child.visits;
      const explore = explorationC * Math.sqrt(Math.log(node.visits) / child.visits);
      const score = exploit + explore;
      if (score > bestScore) { bestScore = score; best = child; }
    }
    return best;
  }

  function expand(node) {
    const idx = Math.floor(Math.random() * node.untried.length);
    const col = node.untried.splice(idx, 1)[0];
    const { board: newBoard } = C4.dropPiece(node.board, col, node.toMove);
    const child = new Node(newBoard, _other(node.toMove), node, col);
    node.children.push(child);
    return child;
  }

  // Light "semi-random" rollout: takes forced wins/blocks, otherwise plays a
  // center-weighted random move. Keeps simulations meaningful within a small budget.
  function rollout(board, toMove) {
    let curBoard = C4.cloneBoard(board);
    let curPlayer = toMove;
    const centerOrder = [3, 2, 4, 1, 5, 0, 6];

    while (true) {
      const winnerRed = C4.checkWin(curBoard, 'red');
      if (winnerRed) return 'red';
      const winnerYellow = C4.checkWin(curBoard, 'yellow');
      if (winnerYellow) return 'yellow';

      const cols = C4.getValidColumns(curBoard);
      if (cols.length === 0) return 'draw';

      const opp = _other(curPlayer);
      let move = null;

      for (const c of cols) {
        if (C4.moveWinsImmediately(curBoard, c, curPlayer)) { move = c; break; }
      }
      if (move === null) {
        for (const c of cols) {
          if (C4.moveWinsImmediately(curBoard, c, opp)) { move = c; break; }
        }
      }
      if (move === null) {
        const weighted = centerOrder.filter(c => cols.includes(c));
        // 70% center-weighted pick, 30% pure random, for rollout diversity
        move = Math.random() < 0.7
          ? weighted[Math.floor(Math.random() * Math.min(3, weighted.length))]
          : cols[Math.floor(Math.random() * cols.length)];
      }

      const res = C4.dropPiece(curBoard, move, curPlayer);
      curBoard = res.board;
      curPlayer = opp;
    }
  }

  function backpropagate(node, winner) {
    let n = node;
    while (n) {
      n.visits += 1;
      if (winner === 'draw') {
        n.wins += 0.5;
      } else if (winner === n.justMoved) {
        n.wins += 1;
      }
      n = n.parent;
    }
  }

  /**
   * Runs MCTS from `board` for player `toMove`, budgeted by time (ms) and iteration cap.
   * Returns { root, iterations, elapsedMs }.
   */
  function search(board, toMove, { timeBudgetMs = 1200, maxIterations = 6000, explorationC = 1.41 } = {}) {
    const root = new Node(C4.cloneBoard(board), toMove, null, null);
    const start = performance.now();
    let iterations = 0;

    while (iterations < maxIterations && (performance.now() - start) < timeBudgetMs) {
      let node = root;

      // 1. Selection
      while (node.untried.length === 0 && node.children.length > 0 && !C4.isTerminal(node.board)) {
        node = uctSelectChild(node, explorationC);
      }

      // 2. Expansion
      if (node.untried.length > 0 && !C4.isTerminal(node.board)) {
        node = expand(node);
      }

      // 3. Simulation
      const winner = C4.isTerminal(node.board)
        ? (C4.checkWin(node.board, 'red') ? 'red' : C4.checkWin(node.board, 'yellow') ? 'yellow' : 'draw')
        : rollout(node.board, node.toMove);

      // 4. Backpropagation
      backpropagate(node, winner);

      iterations++;
    }

    return { root, iterations, elapsedMs: performance.now() - start };
  }

  // ---------- Explanation building ----------

  function columnLabel(c) { return String(c + 1); }

  function buildStatsForRoot(root) {
    // One row per legal column, including unexplored ones (visits 0).
    const rows = [];
    for (let c = 0; c < C4.COLS; c++) {
      if (!C4.isColumnValid(root.board, c)) continue;
      const child = root.children.find(ch => ch.moveFromParent === c);
      rows.push({
        col: c,
        visits: child ? child.visits : 0,
        winRate: child && child.visits > 0 ? child.wins / child.visits : 0,
      });
    }
    rows.sort((a, b) => b.visits - a.visits);
    return rows;
  }

  function centralityNote(col) {
    const windows = C4.COLUMN_WINDOW_COUNTS[col];
    if (col === 3) return `Column 4 is the exact center — it belongs to ${windows} possible four-in-a-row lines, more than any other column, so it's the strongest general-purpose square on the board.`;
    if (windows >= 5) return `Column ${columnLabel(col)} is near-central and sits on ${windows} potential four-in-a-row lines, giving it above-average long-term value.`;
    return `Column ${columnLabel(col)} is on the edge, sitting on only ${windows} potential four-in-a-row lines, so it's usually a lower-priority square unless tactics demand it.`;
  }

  function connectivityNote(board, row, col, player) {
    const n = C4.countNeighbourConnections(board, row, col, player);
    if (n === 0) return null;
    return `It also lands directly beside ${n} existing ${player === 'red' ? 'red' : 'cyan'} disc${n > 1 ? 's' : ''}, reinforcing a cluster rather than starting an isolated one.`;
  }

  /**
   * Top-level decision function. Returns:
   * { col, explanation: { kind, title, body, notes: [...], stats: [...]|null, iterations, elapsedMs } }
   */
  function decide(board, player, options = {}) {
    const validCols = C4.getValidColumns(board);
    const opp = _other(player);

    // 1. Immediate win
    for (const c of validCols) {
      const winCells = C4.moveWinsImmediately(board, c, player);
      if (winCells) {
        return {
          col: c,
          explanation: {
            kind: 'tactical',
            title: `Column ${columnLabel(c)} wins the game immediately.`,
            body: `Dropping here completes four in a row, so no search is needed — I take the win on the spot.`,
            notes: [],
            stats: null,
            iterations: 0,
            elapsedMs: 0,
          },
        };
      }
    }

    // 2. Immediate block
    const forcedBlocks = [];
    for (const c of validCols) {
      if (C4.moveWinsImmediately(board, c, opp)) forcedBlocks.push(c);
    }
    if (forcedBlocks.length > 0) {
      const c = forcedBlocks[0];
      const multi = forcedBlocks.length > 1;
      return {
        col: c,
        explanation: {
          kind: 'tactical',
          title: multi
            ? `Column ${columnLabel(c)} blocks the more urgent of two open threats.`
            : `Column ${columnLabel(c)} blocks your winning threat.`,
          body: multi
            ? `You have two different ways to win next turn (columns ${forcedBlocks.map(columnLabel).join(' and ')}). I can only stop one directly, so I'm playing the block that also gives me the better follow-up position; the game may still be lost from here, but this is the correct defensive try.`
            : `If I don't play here, you complete four in a row on your next move. Blocking overrides everything else this turn.`,
          notes: [],
          stats: null,
          iterations: 0,
          elapsedMs: 0,
        },
      };
    }

    // 3. MCTS search
    const timeBudgetMs = options.timeBudgetMs ?? 1200;
    const { root, iterations, elapsedMs } = search(board, player, { timeBudgetMs });
    const stats = buildStatsForRoot(root);
    const chosen = stats[0];
    const c = chosen.col;
    const runnerUp = stats[1];

    const { row } = C4.dropPiece(board, c, player);
    const notes = [];
    notes.push(centralityNote(c));
    const connNote = connectivityNote(board, row, c, player);
    if (connNote) notes.push(connNote);

    let marginNote;
    if (runnerUp) {
      const gap = chosen.visits - runnerUp.visits;
      const gapPct = ((gap / iterations) * 100).toFixed(0);
      if (gap / iterations < 0.04) {
        marginNote = `This was a close call — column ${columnLabel(c)} only edged out column ${columnLabel(runnerUp.col)} by about ${gapPct}% of the search effort, so either would be a reasonable human choice here.`;
      } else {
        marginNote = `The search converged clearly on this move: it received ${gapPct}% more of the total simulations than the next-best option, column ${columnLabel(runnerUp.col)}.`;
      }
      notes.push(marginNote);
    }

    const pct = (iterations > 0 ? (chosen.visits / iterations) * 100 : 0).toFixed(1);
    const winPct = (chosen.winRate * 100).toFixed(1);

    return {
      col: c,
      explanation: {
        kind: 'search',
        title: `Column ${columnLabel(c)} — chosen after ${iterations.toLocaleString()} simulated games.`,
        body: `I ran Monte Carlo Tree Search from this position: ${iterations.toLocaleString()} playouts in ${(elapsedMs / 1000).toFixed(2)}s. Column ${columnLabel(c)} received the most visits (${pct}% of the search) and an estimated ${winPct}% win rate from here, making it the statistically strongest move rather than a hand-coded rule.`,
        notes,
        stats,
        iterations,
        elapsedMs,
      },
    };
  }

  return { search, decide, _other };
})();
