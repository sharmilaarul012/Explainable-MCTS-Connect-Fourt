/**
 * Ambient 3D particle field + reactive bursts, built with Three.js.
 * Degrades gracefully (no crash) if THREE failed to load (e.g. offline).
 */
const ParticleField = (() => {
  let scene, camera, renderer, canvas;
  let field, fieldGeo, fieldVelocities;
  let bursts = [];
  let clock;
  let enabled = false;
  let mouse = { x: 0, y: 0 };

  const FIELD_COUNT = 1400;
  const COLORS = [
    new (window.THREE ? THREE.Color : Object)(0xff5d5d),
    new (window.THREE ? THREE.Color : Object)(0x47e0ff),
    new (window.THREE ? THREE.Color : Object)(0x9b7bff),
  ];

  function makeGlowTexture() {
    const size = 64;
    const c = document.createElement('canvas');
    c.width = c.height = size;
    const ctx = c.getContext('2d');
    const grad = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    grad.addColorStop(0, 'rgba(255,255,255,1)');
    grad.addColorStop(0.35, 'rgba(255,255,255,0.55)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    return new THREE.CanvasTexture(c);
  }

  function init() {
    canvas = document.getElementById('particle-canvas');
    if (!canvas || typeof THREE === 'undefined') {
      if (canvas) canvas.style.display = 'none';
      return;
    }

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 200);
    camera.position.z = 34;

    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);

    clock = new THREE.Clock();
    const glowTex = makeGlowTexture();

    // Ambient field
    fieldGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(FIELD_COUNT * 3);
    const colors = new Float32Array(FIELD_COUNT * 3);
    const sizes = new Float32Array(FIELD_COUNT);
    fieldVelocities = new Float32Array(FIELD_COUNT * 3);

    for (let i = 0; i < FIELD_COUNT; i++) {
      const i3 = i * 3;
      positions[i3] = (Math.random() - 0.5) * 70;
      positions[i3 + 1] = (Math.random() - 0.5) * 46;
      positions[i3 + 2] = (Math.random() - 0.5) * 50 - 10;

      const col = COLORS[Math.floor(Math.random() * COLORS.length)];
      colors[i3] = col.r; colors[i3 + 1] = col.g; colors[i3 + 2] = col.b;

      sizes[i] = Math.random() * 1.6 + 0.4;

      fieldVelocities[i3] = (Math.random() - 0.5) * 0.02;
      fieldVelocities[i3 + 1] = Math.random() * 0.015 + 0.004;
      fieldVelocities[i3 + 2] = (Math.random() - 0.5) * 0.01;
    }
    fieldGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    fieldGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    fieldGeo.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

    const fieldMat = new THREE.PointsMaterial({
      size: 0.9,
      map: glowTex,
      vertexColors: true,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    field = new THREE.Points(fieldGeo, fieldMat);
    scene.add(field);

    window.addEventListener('resize', onResize);
    window.addEventListener('pointermove', onPointerMove);

    enabled = true;
    animate();
  }

  function onResize() {
    if (!enabled) return;
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  }

  function onPointerMove(e) {
    mouse.x = (e.clientX / window.innerWidth - 0.5) * 2;
    mouse.y = (e.clientY / window.innerHeight - 0.5) * 2;
  }

  // Spawns a short-lived burst of particles at a normalized screen position (0..1, 0..1).
  function burst(nx, ny, colorHex, count = 46) {
    if (!enabled) return;
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);

    const vec = new THREE.Vector3((nx * 2 - 1), -(ny * 2 - 1), 0.5);
    vec.unproject(camera);
    const dir = vec.sub(camera.position).normalize();
    const dist = -camera.position.z / dir.z;
    const origin = camera.position.clone().add(dir.multiplyScalar(dist));

    const col = new THREE.Color(colorHex);
    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      positions[i3] = origin.x;
      positions[i3 + 1] = origin.y;
      positions[i3 + 2] = origin.z;

      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 0.22 + 0.05;
      velocities[i3] = Math.cos(angle) * speed;
      velocities[i3 + 1] = Math.random() * 0.26 + 0.05;
      velocities[i3 + 2] = Math.sin(angle) * speed;

      colors[i3] = col.r; colors[i3 + 1] = col.g; colors[i3 + 2] = col.b;
    }

    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const mat = new THREE.PointsMaterial({
      size: 1.1,
      map: makeGlowTexture(),
      vertexColors: true,
      transparent: true,
      opacity: 1,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    const points = new THREE.Points(geo, mat);
    scene.add(points);
    bursts.push({ points, velocities, age: 0, life: 1.4 });
  }

  function celebrate() {
    if (!enabled) return;
    for (let i = 0; i < 3; i++) {
      setTimeout(() => {
        burst(0.2 + Math.random() * 0.6, 0.15 + Math.random() * 0.3,
          Math.random() > 0.5 ? 0xff5d5d : 0x47e0ff, 90);
      }, i * 160);
    }
  }

  function animate() {
    if (!enabled) return;
    requestAnimationFrame(animate);
    const dt = clock.getDelta();
    const t = clock.getElapsedTime();

    // Ambient drift
    const pos = fieldGeo.attributes.position.array;
    for (let i = 0; i < FIELD_COUNT; i++) {
      const i3 = i * 3;
      pos[i3] += fieldVelocities[i3];
      pos[i3 + 1] += fieldVelocities[i3 + 1];
      pos[i3 + 2] += fieldVelocities[i3 + 2];
      if (pos[i3 + 1] > 24) pos[i3 + 1] = -24;
      if (pos[i3] > 36) pos[i3] = -36;
      if (pos[i3] < -36) pos[i3] = 36;
    }
    fieldGeo.attributes.position.needsUpdate = true;

    field.rotation.y = t * 0.012;
    field.rotation.x = Math.sin(t * 0.05) * 0.05;

    camera.position.x += (mouse.x * 3 - camera.position.x) * 0.02;
    camera.position.y += (-mouse.y * 2 - camera.position.y) * 0.02;
    camera.lookAt(0, 0, 0);

    // Bursts
    for (let i = bursts.length - 1; i >= 0; i--) {
      const b = bursts[i];
      b.age += dt;
      const bp = b.points.geometry.attributes.position.array;
      for (let j = 0; j < bp.length / 3; j++) {
        const j3 = j * 3;
        bp[j3] += b.velocities[j3];
        bp[j3 + 1] += b.velocities[j3 + 1];
        bp[j3 + 2] += b.velocities[j3 + 2];
        b.velocities[j3 + 1] -= 0.006; // gravity
      }
      b.points.geometry.attributes.position.needsUpdate = true;
      b.points.material.opacity = Math.max(0, 1 - b.age / b.life);

      if (b.age >= b.life) {
        scene.remove(b.points);
        b.points.geometry.dispose();
        b.points.material.dispose();
        bursts.splice(i, 1);
      }
    }

    renderer.render(scene, camera);
  }

  return { init, burst, celebrate };
})();
