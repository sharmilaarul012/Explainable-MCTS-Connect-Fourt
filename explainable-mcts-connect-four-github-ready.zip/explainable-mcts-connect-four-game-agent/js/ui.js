/**
 * DOM rendering + interaction layer. Talks to C4 (rules) and MCTSAgent (decisions).
 */
const UI = (() => {
  const els = {};
  let cellEls = []; // [row][col] -> element
  let discEls = [];
  let colHintEls = [];

  function cacheEls() {
    els.board = document.getElementById('board');
    els.colHints = document.getElementById('col-hints');
    els.winLine = document.getElementById('win-line');
    els.turnIndicator = document.getElementById('turn-indicator');
    els.turnText = document.getElementById('turn-text');
    els.thinkingBadge = document.getElementById('thinking-badge');
    els.reasoningEmpty = document.getElementById('reasoning-empty');
    els.reasoningContent = document.getElementById('reasoning-content');
    els.reasoningKind = document.getElementById('reasoning-kind');
    els.reasoningTitle = document.getElementById('reasoning-title');
    els.reasoningBody = document.getElementById('reasoning-body');
    els.statBars = document.getElementById('stat-bars');
    els.simCount = document.getElementById('sim-count');
    els.reasoningNotes = document.getElementById('reasoning-notes');
    els.moveHistory = document.getElementById('move-history');
    els.scoreHuman = document.getElementById('score-human');
    els.scoreAI = document.getElementById('score-ai');
    els.scoreDraw = document.getElementById('score-draw');
    els.endgameOverlay = document.getElementById('endgame-overlay');
    els.endgameTitle = document.getElementById('endgame-title');
    els.endgameSub = document.getElementById('endgame-sub');
    els.endgameAgain = document.getElementById('endgame-again');
    els.newGameBtn = document.getElementById('new-game-btn');
    els.strengthSelect = document.getElementById('strength');
  }

  function buildBoard() {
    els.board.innerHTML = '';
    els.colHints.innerHTML = '';
    cellEls = [];
    discEls = [];
    colHintEls = [];

    for (let c = 0; c < C4.COLS; c++) {
      const hint = document.createElement('div');
      hint.className = 'col-hint';
      hint.dataset.col = c;
      els.colHints.appendChild(hint);
      colHintEls.push(hint);
    }

    for (let r = 0; r < C4.ROWS; r++) {
      const rowCells = [];
      const rowDiscs = [];
      for (let c = 0; c < C4.COLS; c++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.dataset.row = r;
        cell.dataset.col = c;
        const disc = document.createElement('div');
        disc.className = 'disc';
        cell.appendChild(disc);
        els.board.appendChild(cell);
        rowCells.push(cell);
        rowDiscs.push(disc);
      }
      cellEls.push(rowCells);
      discEls.push(rowDiscs);
    }
  }

  function highlightColumn(col) {
    colHintEls.forEach((h, i) => h.classList.toggle('active', i === col));
  }

  function clearHighlight() {
    colHintEls.forEach(h => h.classList.remove('active'));
  }

  function placeDisc(row, col, player, isWinningCell = false) {
    const disc = discEls[row][col];
    disc.classList.add(player);
    // force reflow so the fall animation restarts cleanly
    void disc.offsetWidth;
    disc.classList.add('dropped');
    if (isWinningCell) disc.classList.add('win-cell');
  }

  function markWinningCells(cells) {
    for (const { r, c } of cells) {
      discEls[r][c].classList.add('win-cell');
    }
  }

  function drawWinLine(cells) {
    if (!cells || cells.length < 2) return;
    const boardRect = els.board.getBoundingClientRect();
    const first = cellEls[cells[0].r][cells[0].c].getBoundingClientRect();
    const last = cellEls[cells[3].r][cells[3].c].getBoundingClientRect();

    const vb = els.winLine.viewBox.baseVal;
    const scaleX = vb.width / boardRect.width;
    const scaleY = vb.height / boardRect.height;

    const x1 = (first.left + first.width / 2 - boardRect.left) * scaleX;
    const y1 = (first.top + first.height / 2 - boardRect.top) * scaleY;
    const x2 = (last.left + last.width / 2 - boardRect.left) * scaleX;
    const y2 = (last.top + last.height / 2 - boardRect.top) * scaleY;

    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', x1); line.setAttribute('y1', y1);
    line.setAttribute('x2', x2); line.setAttribute('y2', y2);
    els.winLine.appendChild(line);
    requestAnimationFrame(() => line.classList.add('show'));
  }

  function clearWinLine() {
    els.winLine.innerHTML = '';
  }

  function setTurnIndicator(mode) {
    // mode: 'human' | 'ai-thinking' | 'ai-moved' | 'over'
    els.turnIndicator.classList.remove('turn-pill--human', 'turn-pill--ai');
    if (mode === 'human') {
      els.turnIndicator.classList.add('turn-pill--human');
      els.turnText.textContent = 'Your move — drop a disc';
      els.thinkingBadge.classList.add('hidden');
    } else if (mode === 'ai-thinking') {
      els.turnIndicator.classList.add('turn-pill--ai');
      els.turnText.textContent = 'Lumen is searching…';
      els.thinkingBadge.classList.remove('hidden');
    } else if (mode === 'ai-moved') {
      els.turnIndicator.classList.add('turn-pill--ai');
      els.turnText.textContent = 'Lumen moved — your turn';
      els.thinkingBadge.classList.add('hidden');
    } else {
      els.thinkingBadge.classList.add('hidden');
    }
  }

  function renderExplanation(explanation) {
    els.reasoningEmpty.classList.add('hidden');
    els.reasoningContent.classList.remove('hidden');

    els.reasoningKind.textContent = explanation.kind === 'tactical' ? 'TACTICAL' : 'MCTS SEARCH';
    els.reasoningKind.classList.toggle('tactical', explanation.kind === 'tactical');
    els.reasoningTitle.textContent = explanation.title;
    els.reasoningBody.textContent = explanation.body;

    els.reasoningNotes.innerHTML = '';
    for (const note of explanation.notes) {
      if (!note) continue;
      const li = document.createElement('li');
      li.textContent = note;
      els.reasoningNotes.appendChild(li);
    }

    els.statBars.innerHTML = '';
    if (explanation.stats && explanation.stats.length) {
      els.simCount.textContent = `${explanation.iterations.toLocaleString()} sims · ${(explanation.elapsedMs / 1000).toFixed(2)}s`;
      const maxVisits = Math.max(...explanation.stats.map(s => s.visits), 1);
      const topCol = explanation.stats[0].col;
      for (const row of explanation.stats) {
        const rowEl = document.createElement('div');
        rowEl.className = 'stat-bar-row';

        const label = document.createElement('span');
        label.className = 'stat-bar-col';
        label.textContent = row.col + 1;

        const track = document.createElement('div');
        track.className = 'stat-bar-track';
        const fill = document.createElement('div');
        fill.className = 'stat-bar-fill' + (row.col === topCol ? ' chosen' : '');
        track.appendChild(fill);

        const pct = document.createElement('span');
        pct.className = 'stat-bar-pct';
        const visitPct = ((row.visits / (explanation.iterations || 1)) * 100).toFixed(0);
        pct.textContent = row.visits > 0 ? `${visitPct}% · ${(row.winRate * 100).toFixed(0)}%W` : '—';

        rowEl.appendChild(label);
        rowEl.appendChild(track);
        rowEl.appendChild(pct);
        els.statBars.appendChild(rowEl);

        requestAnimationFrame(() => {
          fill.style.width = `${(row.visits / maxVisits) * 100}%`;
        });
      }
    } else {
      els.simCount.textContent = 'no search needed';
    }
  }

  function addMoveHistory(player, col, note) {
    const li = document.createElement('li');
    const dot = document.createElement('span');
    dot.className = `mh-dot ${player === 'red' ? 'red' : 'yellow'}`;
    const label = document.createElement('span');
    label.textContent = `${player === 'red' ? 'You' : 'Lumen'} → column ${col + 1}${note ? '  ·  ' + note : ''}`;
    li.appendChild(dot);
    li.appendChild(label);
    els.moveHistory.insertBefore(li, els.moveHistory.firstChild);
  }

  function clearMoveHistory() {
    els.moveHistory.innerHTML = '';
  }

  function resetReasoningPanel() {
    els.reasoningEmpty.classList.remove('hidden');
    els.reasoningContent.classList.add('hidden');
  }

  function showEndgame(kind, title, sub) {
    els.endgameTitle.textContent = title;
    els.endgameSub.textContent = sub;
    els.endgameOverlay.classList.remove('hidden');
  }

  function hideEndgame() {
    els.endgameOverlay.classList.add('hidden');
  }

  function updateScores(human, ai, draw) {
    els.scoreHuman.textContent = human;
    els.scoreAI.textContent = ai;
    els.scoreDraw.textContent = draw;
  }

  function cellCenterNormalized(row, col) {
    const rect = cellEls[row][col].getBoundingClientRect();
    return {
      nx: (rect.left + rect.width / 2) / window.innerWidth,
      ny: (rect.top + rect.height / 2) / window.innerHeight,
    };
  }

  function columnTopNormalized(col) {
    const rect = cellEls[0][col].getBoundingClientRect();
    return {
      nx: (rect.left + rect.width / 2) / window.innerWidth,
      ny: rect.top / window.innerHeight,
    };
  }

  return {
    cacheEls, buildBoard, highlightColumn, clearHighlight,
    placeDisc, markWinningCells, drawWinLine, clearWinLine,
    setTurnIndicator, renderExplanation, addMoveHistory, clearMoveHistory,
    resetReasoningPanel, showEndgame, hideEndgame, updateScores,
    cellCenterNormalized, columnTopNormalized,
    get els() { return els; },
  };
})();
