(function () {
  const HUMAN = 'red';
  const AI = 'yellow';

  let board = C4.createBoard();
  let current = HUMAN;
  let gameOver = false;
  let animating = false;
  let scores = { human: 0, ai: 0, draw: 0 };

  function init() {
    UI.cacheEls();
    UI.buildBoard();
    ParticleField.init();
    bindEvents();
    UI.setTurnIndicator('human');
  }

  function bindEvents() {
    UI.els.board.addEventListener('click', onBoardClick);
    UI.els.board.addEventListener('mousemove', onBoardHover);
    UI.els.board.addEventListener('mouseleave', () => UI.clearHighlight());
    UI.els.newGameBtn.addEventListener('click', resetGame);
    UI.els.endgameAgain.addEventListener('click', () => { UI.hideEndgame(); resetGame(); });
    window.addEventListener('resize', () => { UI.clearWinLine(); });
  }

  function onBoardHover(e) {
    const col = colFromEvent(e);
    if (col === null) { UI.clearHighlight(); return; }
    UI.highlightColumn(col);
  }

  function colFromEvent(e) {
    const rect = UI.els.board.getBoundingClientRect();
    const relX = e.clientX - rect.left;
    const colWidth = rect.width / C4.COLS;
    const col = Math.floor(relX / colWidth);
    if (col < 0 || col >= C4.COLS) return null;
    return col;
  }

  function onBoardClick(e) {
    if (gameOver || animating || current !== HUMAN) return;
    const col = colFromEvent(e);
    if (col === null || !C4.isColumnValid(board, col)) return;
    playHumanMove(col);
  }

  function playHumanMove(col) {
    const result = C4.dropPiece(board, col, HUMAN);
    if (!result) return;
    animating = true;
    board = result.board;

    UI.placeDisc(result.row, col, HUMAN);
    const { nx, ny } = UI.cellCenterNormalized(result.row, col);
    ParticleField.burst(nx, ny, 0xff5d5d, 22);
    UI.addMoveHistory(HUMAN, col, null);

    setTimeout(() => {
      animating = false;
      if (checkEnd()) return;
      current = AI;
      setTimeout(aiTurn, 260);
    }, 620);
  }

  function aiTurn() {
    UI.setTurnIndicator('ai-thinking');
    UI.clearHighlight();
    const timeBudgetMs = parseInt(UI.els.strengthSelect.value, 10);

    // Let the "thinking" state paint before we block the main thread with search.
    setTimeout(() => {
      const { col, explanation } = MCTSAgent.decide(board, AI, { timeBudgetMs });
      const result = C4.dropPiece(board, col, AI);
      board = result.board;
      animating = true;

      UI.placeDisc(result.row, col, AI);
      const { nx, ny } = UI.cellCenterNormalized(result.row, col);
      ParticleField.burst(nx, ny, 0x47e0ff, 26);

      UI.renderExplanation(explanation);
      const shortNote = explanation.kind === 'tactical' ? 'tactical' : `${explanation.iterations.toLocaleString()} sims`;
      UI.addMoveHistory(AI, col, shortNote);

      setTimeout(() => {
        animating = false;
        if (checkEnd()) return;
        current = HUMAN;
        UI.setTurnIndicator('human');
      }, 620);
    }, 120);
  }

  function checkEnd() {
    const redWin = C4.checkWin(board, 'red');
    const yellowWin = C4.checkWin(board, 'yellow');

    if (redWin) {
      gameOver = true;
      UI.markWinningCells(redWin);
      UI.drawWinLine(redWin);
      scores.human++;
      UI.updateScores(scores.human, scores.ai, scores.draw);
      ParticleField.celebrate();
      UI.setTurnIndicator('over');
      setTimeout(() => UI.showEndgame('human', 'You win', 'Four red discs in a row — well played.'), 700);
      return true;
    }
    if (yellowWin) {
      gameOver = true;
      UI.markWinningCells(yellowWin);
      UI.drawWinLine(yellowWin);
      scores.ai++;
      UI.updateScores(scores.human, scores.ai, scores.draw);
      ParticleField.celebrate();
      UI.setTurnIndicator('over');
      setTimeout(() => UI.showEndgame('ai', 'Lumen wins', 'Check the reasoning log for how it got there.'), 700);
      return true;
    }
    if (C4.isDraw(board)) {
      gameOver = true;
      scores.draw++;
      UI.updateScores(scores.human, scores.ai, scores.draw);
      UI.setTurnIndicator('over');
      setTimeout(() => UI.showEndgame('draw', "It's a draw", 'The board filled up with no four in a row.'), 400);
      return true;
    }
    return false;
  }

  function resetGame() {
    board = C4.createBoard();
    current = HUMAN;
    gameOver = false;
    animating = false;
    UI.buildBoard();
    UI.clearWinLine();
    UI.resetReasoningPanel();
    UI.clearMoveHistory();
    UI.setTurnIndicator('human');
  }

  document.addEventListener('DOMContentLoaded', init);
})();
